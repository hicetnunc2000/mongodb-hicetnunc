# mongodb-hicetnunc

`
https://vj4pzbqrsa.execute-api.us-east-1.amazonaws.com/dev/objkt?token_id=30000
https://vj4pzbqrsa.execute-api.us-east-1.amazonaws.com/dev/tag?tag=GAN
https://vj4pzbqrsa.execute-api.us-east-1.amazonaws.com/dev/objkts { arr : [ 30000 ] }
`

